﻿namespace Assets.UiTest.Results
{
    public interface ICommandResult
    {
    }
}