public interface IUiTestShop
{
    IUiTestShopObjects Packs { get; }
    IUiTestShopObjects Categories { get; }
}