
    using Assets.UiTest.Context;

    public interface IUiTestShopObjects
    {
        string GetShopObjectName(string packId);
        string GetShopGoName();
    }
