﻿namespace Assets.UiTest.TestSteps
{
    public enum TestStepState
    {
        Done,
        Fail,
        Progress,
        None,
        Stop
    }
}