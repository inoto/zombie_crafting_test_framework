namespace UiTest.UiTest.Checker
{
    public interface IUiTestChecker
    {
        void Init();
        bool Check();
    }
}