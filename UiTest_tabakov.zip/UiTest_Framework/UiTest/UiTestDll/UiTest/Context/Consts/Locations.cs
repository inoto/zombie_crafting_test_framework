namespace Assets.UiTest.Context.Consts
{
    public class Locations
    {
        public static readonly Home Home = new Home();
    }
}