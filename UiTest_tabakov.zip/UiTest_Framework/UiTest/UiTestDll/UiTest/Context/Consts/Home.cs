namespace Assets.UiTest.Context.Consts
{
    public class Home
    {
        private const string _id = "home";
        public readonly string Id = "home";
        public readonly StringParam WorkbenchSawmill=new StringParam("workbench_sawmill",_id);
    }
}