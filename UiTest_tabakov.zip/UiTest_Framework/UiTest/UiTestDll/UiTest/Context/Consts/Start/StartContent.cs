namespace Assets.UiTest.Context.Consts
{
    public class StartContent 
    {
        public static readonly string Id = "start";
        public StringParam StartScreen = new StringParam("start_screen", Id);
    }
}