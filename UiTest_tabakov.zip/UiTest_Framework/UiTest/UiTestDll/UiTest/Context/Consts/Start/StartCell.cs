namespace Assets.UiTest.Context.Consts
{
    public class StartCell
    {
        public static readonly string Id = "start";
    }
}