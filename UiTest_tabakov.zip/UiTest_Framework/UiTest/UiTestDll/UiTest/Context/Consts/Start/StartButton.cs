namespace Assets.UiTest.Context.Consts
{
    public class StartButton
    {
        public static readonly string Id = "main";
    }
}