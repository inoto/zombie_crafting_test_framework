namespace UiTest.UiTest.Coroutine
{
    public interface ITestRoutine
    {
        IStatus Run();
        void Stop();
    }
}