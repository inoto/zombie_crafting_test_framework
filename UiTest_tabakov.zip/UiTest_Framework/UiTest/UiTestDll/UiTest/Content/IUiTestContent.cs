﻿using UnityEngine;

namespace Assets.UiTest.ContentGroup
{
    public interface IUiTestContent 
    {
        GameObject GetGO();
    }
}