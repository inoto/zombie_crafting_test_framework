﻿namespace Assets.UiTest.Buttons
{
    public interface IUiUpDownTestButton
    {
        void Down();
        void Up();
    }
}